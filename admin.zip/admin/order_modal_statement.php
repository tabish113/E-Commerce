<div id="addphotos" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
     <div class="modal-header">
          <div class="alert alert-gray">
               Select Statement Period
          </div>
          <div class="modal-body"><hr>
               <form class="form-horizontal" method="POST" action="order_statement.php" enctype="multipart/form-data">
                     <div class="control-group">
                          <label class="control-label" for="inputEmail">Invoice Number</label>
                                 <div class="controls">
                                </div>
                     </div>
                     <div class="control-group">
                          <label class="control-label" for="inputEmail">From</label>
                                 <div class="controls">
                                 <input type="text" class="span10" name="category1"  required >
                                </div>
                     </div>
                     <div class="control-group">
                          <label class="control-label" for="inputEmail">To</label>
                                 <div class="controls">
                                 <input type="text" class="span10" id="inputEmail" name="category2"  required>
                                </div>
                     </div>
               </div>
               <div class="modal-footer">
                     <button name="save" type="submit" class="btn btn-success"><i class="icon-pencil"></i>&nbsp;Post</button>
                     <button class="btn" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i>&nbsp;Close</button>
              </form>  
      </div>
</div>