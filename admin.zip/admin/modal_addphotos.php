<div id="addphotos" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
     <div class="modal-header">
          <div class="alert alert-gray">
               Add New Product
          </div>
          <div class="modal-body"><hr>
               <form class="form-horizontal" method="POST" enctype="multipart/form-data">
                     <div class="control-group">
                           <label class="control-label" for="inputEmail">Name</label>
                                  <div class="controls">
                                       <input type="text" class="span10" id="inputEmail" name="title" placeholder="Title" required class="span3">
                                  </div>
                     </div>
                     <div class="control-group">
                          <label class="control-label" for="input01">Image 1</label>
                                 <div class="controls">
                                      <input type="file" name="image1" class="font"> 
                                 </div>
                     </div>
                     <div class="control-group">
                          <label class="control-label" for="input01">Image 2</label>
                                 <div class="controls">
                                      <input type="file" name="image2" class="font"> 
                                 </div>
                     </div>
                     <div class="control-group">
                          <label class="control-label" for="input01">Image 3</label>
                                 <div class="controls">
                                      <input type="file" name="image3" class="font"> 
                                 </div>
                     </div>
                     <div class="control-group">
                          <label class="control-label" for="input01">Image 4</label>
                                 <div class="controls">
                                      <input type="file" name="image4" class="font" > 
                                 </div>
                     </div>
                     <div class="control-group">
                          <label class="control-label" for="input01">Image 5</label>
                                 <div class="controls">
                                      <input type="file" name="image5" class="font" > 
                                 </div>
                     </div>
                     <div class="control-group">
                          <label class="control-label" for="input01">Image 6</label>
                                 <div class="controls">
                                      <input type="file" name="image6" class="font" > 
                                 </div>
                     </div>
                     <div class="control-group">
                          <label class="control-label" for="inputEmail">MRP</label>
                                 <div class="controls">
                                      <input type="text" class="span10" id="inputEmail" name="mrp" placeholder="MRP" required class="span3">

                                 </div>
                     </div>
                     <div class="control-group">
                          <label class="control-label" for="inputEmail">Cost Price</label>
                                 <div class="controls">
                                      <input type="text" class="span10" id="inputEmail" name="cprice" placeholder="Cost Price" required class="span3">

                                 </div>
                     </div>


                     <div class="control-group">
                          <label class="control-label" for="inputEmail">Selling Price</label>
                                 <div class="controls">
                                      <input type="text" class="span10" id="inputEmail" name="price" placeholder="Selling Price" required class="span3">
                                 </div>
                     </div>

                     <div class="control-group">
                          <label class="control-label" for="inputEmail">Category</label>
                                 <div class="controls">
                                      <select name="category" required> 
                                                             <option value="null">Select</option>
                                                  
                                                             
                                                             <option  value="Bags">Design</option>
                                                             <option value="Grocery">Grocery</option>
                                             
                                             
                                     </select>
                                </div>
                     </div>
                     <div class="control-group">
                          <label class="control-label" for="inputEmail">Sub Category</label>
                                 <div class="controls">
                                      <select name="sub_cat" required> 
                                                              
                                                  
                                                             <option  value="Ramzan">Ramzan</option>
                                                             <option  value="rice">Rice</option>
                                                             <option  value="Wheat Atta">Wheat Atta</option>
                                                             <option  value="Oils">Oils & Ghee</option>
                                                             <option  value="Dals">Dals & Pulses</option>
                                                             <option  value="Namkeen Biscuit">Sauces & Jams</option>
                                                             <option  value="Biscuit">Biscuit</option>
                                                             <option  value="Masalas">Masalas & Spices</option>
                                                             <option  value="Snacks">Snacks</option>
                                                             <option  value="Beverages">Beverages</option>
                                                             <option  value="Noodles">Instant Foods</option>
                                                             <option  value="Chocolates">Chocolates</option>
                                                             <option  value="pickles">Pickles & Fries</option>
                                                             <option  value="Personal">Personal Care</option>
                                                             <option  value="Household">Household</option>
                                                             <option  value="Dry Fruits">Dry Fruits</option>
                                                             <option  value="Kids">Kids</option>
                                                             
                                                             
                                     </select>
                                </div>
                     </div>

                   <div class="control-group">
                          <label class="control-label" for="inputEmail">P-care sub-cat</label>
                                 <div class="controls">
                                      <select name="sub_cat_p" > 
                                                             <option value="null">Select</option>
                                                  
                                                             <option  value="skin">Skin Care</option>
                                                             <option  value="hair">Hair Care</option>
                                                             <option  value="soap">Soaps</option>
                                                             <option  value="face">Face Wash & Cream</option>
                                                             <option  value="hygiene">Hygiene</option>
                                                             <option  value="perfume">Perfume & Deodorants</option>
                                                             
                                     </select>
                                </div>
                     </div>

<div class="control-group">
                          <label class="control-label" for="inputEmail">Quantity</label>
                                 <div class="controls">
                              <input type="number" class="span10"  required  name="quantity">
                                 </div></div>

         <div class="control-group">
                          <label class="control-label" for="inputEmail">Danger</label>
                                 <div class="controls">
                              <input type="number" class="span10"  required  name="danger">
                                 </div></div>


                     <div class="control-group">
                          <label class="control-label" for="inputEmail">Weight</label>
                                 <div class="controls">
                              <input rows="5" class="span10" required placeholder="Write product weight..!" name="weight">
                                 </div>
                      </div>
                      <div class="control-group">
                          <label class="control-label" for="inputEmail">Status</label>
                                 <div class="controls">
                                      <select name="status"> 
                                             
                                                             <option  value="stock">Stock</option>
                                             
                                                             <option value="out of stock">Out of Stock</option>
                                                             <option  value="hide">Hide</option>

                                             </optgroup>
                                     </select>
                                </div>
                     </div>
                     
                     <div class="control-group">
                          <label class="control-label" for="inputEmail">Description</label>
                                 <div class="controls">
                                      <textarea rows="5" class="span10"  placeholder="Write your details here..!" name="content"></textarea>
                                 </div>
                    </div>
               </div>
               <div class="modal-footer">
                     <button name="save" type="submit" class="btn btn-success"><i class="icon-pencil"></i>&nbsp;Post</button>
                     <button class="btn" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i>&nbsp;Close</button>
              </form>  
      </div>
</div>
<?php
     include('dbcon.php');
     if(isset($_POST['save'])){
     $title=$_POST['title'];

error_reporting(0);
$change="";
$abc="";
define ("MAX_SIZE","400");
function getExtension($str) {
         $i = strrpos($str,".");
         if (!$i) { return ""; }
         $l = strlen($str) - $i;
         $ext = substr($str,$i+1,$l);
         return $ext;
}
$errors=0;
if($_SERVER["REQUEST_METHOD"] == "POST"){
$g111=end(explode('.',$_FILES['image1']['name']));
$image1='item_'.md5(rand()).'.'.$g111;
$uploadedfile1 = $_FILES['image1']['tmp_name'];
   if ($image1){
             $filename = stripslashes($_FILES['image1']['name']);
             $extension = getExtension($filename);
           $extension = strtolower($extension);
           if (($extension != "jpg") && ($extension != "jpeg") && ($extension != "png") && ($extension != "gif")){
               $change='<div class="msgdiv">Unknown Image extension </div> ';
               $errors=1;
           }
           else{
                    $size=filesize($_FILES['image1']['tmp_name']);
                    if ($size > MAX_SIZE*1024){  
                      $change='<div class="msgdiv">You have exceeded the size limit!</div> ';
                      $errors=1;
                    }
                    if($extension=="jpg" || $extension=="jpeg" ){
                       $uploadedfile1 = $_FILES['image1']['tmp_name'];
                       $src = imagecreatefromjpeg($uploadedfile1);
                    }
                    else if($extension=="png"){
                            $uploadedfile1 = $_FILES['image1']['tmp_name'];
                            $src = imagecreatefrompng($uploadedfile1);
                    }
                    else {
                          $src = imagecreatefromgif($uploadedfile1);
                    }
                    echo $scr;
                    list($width,$height)=getimagesize($uploadedfile1);
                    $newwidth=600;
                    $newheight=($height/$width)*$newwidth;
                    $newwidth1=332;
                    $newheight1=284;
                    $newwidth2=150;
                    $newheight2=150;
                    $newwidth3=36;
                    $newheight3=36;
                    $tmp=imagecreatetruecolor($newwidth,$newheight);
                    $tmp1=imagecreatetruecolor($newwidth1,$newheight1);
                    $tmp2=imagecreatetruecolor($newwidth2,$newheight2);
                    $tmp3=imagecreatetruecolor($newwidth3,$newheight3);

                    imagecopyresampled($tmp,$src,0,0,0,0,$newwidth,$newheight,$width,$height);
                    imagecopyresampled($tmp1,$src,0,0,0,0,$newwidth1,$newheight1,$width,$height);
                    imagecopyresampled($tmp2,$src,0,0,0,0,$newwidth2,$newheight2,$width,$height);
                    imagecopyresampled($tmp3,$src,0,0,0,0,$newwidth3,$newheight3,$width,$height);

                    $filename = "../shop_image/large/".$image1;
                    $filename1 = "../shop_image/md/".$image1;
                    $filename2 = "../shop_image/sm/".$image1;
                    $filename3 = "../shop_image/xs/".$image1;

                    imagejpeg($tmp,$filename,100);
                    imagejpeg($tmp1,$filename1,100);
                    imagejpeg($tmp2,$filename2,100);
                    imagejpeg($tmp3,$filename3,100);

                    imagedestroy($src);
               }
         }
}

if($_SERVER["REQUEST_METHOD"] == "POST"){
$g112=end(explode('.',$_FILES['image2']['name']));
$image2='item_'.md5(rand()).'.'.$g112;
$uploadedfile2 = $_FILES['image2']['tmp_name'];
   if ($image2){
             $filename = stripslashes($_FILES['image2']['name']);
             $extension = getExtension($filename);
           $extension = strtolower($extension);
           if (($extension != "jpg") && ($extension != "jpeg") && ($extension != "png") && ($extension != "gif")){
               $change='<div class="msgdiv">Unknown Image extension </div> ';
               $errors=1;
           }
           else{
                    $size=filesize($_FILES['image2']['tmp_name']);
                    if ($size > MAX_SIZE*1024){  
                      $change='<div class="msgdiv">You have exceeded the size limit!</div> ';
                      $errors=1;
                    }
                    if($extension=="jpg" || $extension=="jpeg" ){
                       $uploadedfile2 = $_FILES['image2']['tmp_name'];
                       $src = imagecreatefromjpeg($uploadedfile2);
                    }
                    else if($extension=="png"){
                            $uploadedfile2 = $_FILES['image2']['tmp_name'];
                            $src = imagecreatefrompng($uploadedfile2);
                    }
                    else {
                          $src = imagecreatefromgif($uploadedfile2);
                    }
                    echo $scr;
                    list($width,$height)=getimagesize($uploadedfile2);
                    $newwidth=600;
                    $newheight=($height/$width)*$newwidth;
                    $newwidth1=332;
                    $newheight1=284;
                    $newwidth2=150;
                    $newheight2=150;
                    $newwidth3=36;
                    $newheight3=36;
                    $tmp=imagecreatetruecolor($newwidth,$newheight);
                    $tmp1=imagecreatetruecolor($newwidth1,$newheight1);
                    $tmp2=imagecreatetruecolor($newwidth2,$newheight2);
                    $tmp3=imagecreatetruecolor($newwidth3,$newheight3);

                    imagecopyresampled($tmp,$src,0,0,0,0,$newwidth,$newheight,$width,$height);
                    imagecopyresampled($tmp1,$src,0,0,0,0,$newwidth1,$newheight1,$width,$height);
                    imagecopyresampled($tmp2,$src,0,0,0,0,$newwidth2,$newheight2,$width,$height);
                    imagecopyresampled($tmp3,$src,0,0,0,0,$newwidth3,$newheight3,$width,$height);

                    $filename = "../shop_image/large/".$image2;
                    $filename1 = "../shop_image/md/".$image2;
                    $filename2 = "../shop_image/sm/".$image2;
                    $filename3 = "../shop_image/xs/".$image2;

                    imagejpeg($tmp,$filename,100);
                    imagejpeg($tmp1,$filename1,100);
                    imagejpeg($tmp2,$filename2,100);
                    imagejpeg($tmp3,$filename3,100);

                    imagedestroy($src);
               }
         }
}

if($_SERVER["REQUEST_METHOD"] == "POST"){
$g113=end(explode('.',$_FILES['image3']['name']));
$image3='item_'.md5(rand()).'.'.$g113;
$uploadedfile3 = $_FILES['image3']['tmp_name'];
   if ($image3){
             $filename = stripslashes($_FILES['image3']['name']);
             $extension = getExtension($filename);
           $extension = strtolower($extension);
           if (($extension != "jpg") && ($extension != "jpeg") && ($extension != "png") && ($extension != "gif")){
               $change='<div class="msgdiv">Unknown Image extension </div> ';
               $errors=1;
           }
           else{
                    $size=filesize($_FILES['image3']['tmp_name']);
                    if ($size > MAX_SIZE*1024){  
                      $change='<div class="msgdiv">You have exceeded the size limit!</div> ';
                      $errors=1;
                    }
                    if($extension=="jpg" || $extension=="jpeg" ){
                       $uploadedfile3 = $_FILES['image3']['tmp_name'];
                       $src = imagecreatefromjpeg($uploadedfile3);
                    }
                    else if($extension=="png"){
                            $uploadedfile3 = $_FILES['image3']['tmp_name'];
                            $src = imagecreatefrompng($uploadedfile3);
                    }
                    else {
                          $src = imagecreatefromgif($uploadedfile3);
                    }
                    echo $scr;
                    list($width,$height)=getimagesize($uploadedfile3);
                    $newwidth=600;
                    $newheight=($height/$width)*$newwidth;
                    $newwidth1=332;
                    $newheight1=284;
                    $newwidth2=150;
                    $newheight2=150;
                    $newwidth3=36;
                    $newheight3=36;
                    $tmp=imagecreatetruecolor($newwidth,$newheight);
                    $tmp1=imagecreatetruecolor($newwidth1,$newheight1);
                    $tmp2=imagecreatetruecolor($newwidth2,$newheight2);
                    $tmp3=imagecreatetruecolor($newwidth3,$newheight3);

                    imagecopyresampled($tmp,$src,0,0,0,0,$newwidth,$newheight,$width,$height);
                    imagecopyresampled($tmp1,$src,0,0,0,0,$newwidth1,$newheight1,$width,$height);
                    imagecopyresampled($tmp2,$src,0,0,0,0,$newwidth2,$newheight2,$width,$height);
                    imagecopyresampled($tmp3,$src,0,0,0,0,$newwidth3,$newheight3,$width,$height);

                    $filename = "../shop_image/large/".$image3;
                    $filename1 = "../shop_image/md/".$image3;
                    $filename2 = "../shop_image/sm/".$image3;
                    $filename3 = "../shop_image/xs/".$image3;

                    imagejpeg($tmp,$filename,100);
                    imagejpeg($tmp1,$filename1,100);
                    imagejpeg($tmp2,$filename2,100);
                    imagejpeg($tmp3,$filename3,100);

                    imagedestroy($src);
               }
         }
}

if($_SERVER["REQUEST_METHOD"] == "POST"){
$g114=end(explode('.',$_FILES['image4']['name']));
$image4='item_'.md5(rand()).'.'.$g114;
$uploadedfile4 = $_FILES['image4']['tmp_name'];
   if ($image4){
             $filename = stripslashes($_FILES['image4']['name']);
             $extension = getExtension($filename);
           $extension = strtolower($extension);
           if (($extension != "jpg") && ($extension != "jpeg") && ($extension != "png") && ($extension != "gif")){
               $change='<div class="msgdiv">Unknown Image extension </div> ';
               $errors=1;
           }
           else{
                    $size=filesize($_FILES['image4']['tmp_name']);
                    if ($size > MAX_SIZE*1024){  
                      $change='<div class="msgdiv">You have exceeded the size limit!</div> ';
                      $errors=1;
                    }
                    if($extension=="jpg" || $extension=="jpeg" ){
                       $uploadedfile4 = $_FILES['image4']['tmp_name'];
                       $src = imagecreatefromjpeg($uploadedfile4);
                    }
                    else if($extension=="png"){
                            $uploadedfile4 = $_FILES['image4']['tmp_name'];
                            $src = imagecreatefrompng($uploadedfile4);
                    }
                    else {
                          $src = imagecreatefromgif($uploadedfile4);
                    }
                    echo $scr;
                    list($width,$height)=getimagesize($uploadedfile4);
                    $newwidth=600;
                    $newheight=($height/$width)*$newwidth;
                    $newwidth1=332;
                    $newheight1=284;
                    $newwidth2=150;
                    $newheight2=150;
                    $newwidth3=36;
                    $newheight3=36;
                    $tmp=imagecreatetruecolor($newwidth,$newheight);
                    $tmp1=imagecreatetruecolor($newwidth1,$newheight1);
                    $tmp2=imagecreatetruecolor($newwidth2,$newheight2);
                    $tmp3=imagecreatetruecolor($newwidth3,$newheight3);

                    imagecopyresampled($tmp,$src,0,0,0,0,$newwidth,$newheight,$width,$height);
                    imagecopyresampled($tmp1,$src,0,0,0,0,$newwidth1,$newheight1,$width,$height);
                    imagecopyresampled($tmp2,$src,0,0,0,0,$newwidth2,$newheight2,$width,$height);
                    imagecopyresampled($tmp3,$src,0,0,0,0,$newwidth3,$newheight3,$width,$height);

                    $filename = "../shop_image/large/".$image4;
                    $filename1 = "../shop_image/md/".$image4;
                    $filename2 = "../shop_image/sm/".$image4;
                    $filename3 = "../shop_image/xs/".$image4;

                    imagejpeg($tmp,$filename,100);
                    imagejpeg($tmp1,$filename1,100);
                    imagejpeg($tmp2,$filename2,100);
                    imagejpeg($tmp3,$filename3,100);

                    imagedestroy($src);
               }
         }
}

if($_SERVER["REQUEST_METHOD"] == "POST"){
$g115=end(explode('.',$_FILES['image5']['name']));
$image5='item_'.md5(rand()).'.'.$g115;
$uploadedfile5 = $_FILES['image5']['tmp_name'];
   if ($image5){
             $filename = stripslashes($_FILES['image5']['name']);
             $extension = getExtension($filename);
           $extension = strtolower($extension);
           if (($extension != "jpg") && ($extension != "jpeg") && ($extension != "png") && ($extension != "gif")){
               $change='<div class="msgdiv">Unknown Image extension </div> ';
               $errors=1;
           }
           else{
                    $size=filesize($_FILES['image5']['tmp_name']);
                    if ($size > MAX_SIZE*1024){  
                      $change='<div class="msgdiv">You have exceeded the size limit!</div> ';
                      $errors=1;
                    }
                    if($extension=="jpg" || $extension=="jpeg" ){
                       $uploadedfile5 = $_FILES['image5']['tmp_name'];
                       $src = imagecreatefromjpeg($uploadedfile5);
                    }
                    else if($extension=="png"){
                            $uploadedfile5 = $_FILES['image5']['tmp_name'];
                            $src = imagecreatefrompng($uploadedfile5);
                    }
                    else {
                          $src = imagecreatefromgif($uploadedfile5);
                    }
                    echo $scr;
                    list($width,$height)=getimagesize($uploadedfile5);
                    $newwidth=600;
                    $newheight=($height/$width)*$newwidth;
                    $newwidth1=332;
                    $newheight1=284;
                    $newwidth2=150;
                    $newheight2=150;
                    $newwidth3=36;
                    $newheight3=36;
                    $tmp=imagecreatetruecolor($newwidth,$newheight);
                    $tmp1=imagecreatetruecolor($newwidth1,$newheight1);
                    $tmp2=imagecreatetruecolor($newwidth2,$newheight2);
                    $tmp3=imagecreatetruecolor($newwidth3,$newheight3);

                    imagecopyresampled($tmp,$src,0,0,0,0,$newwidth,$newheight,$width,$height);
                    imagecopyresampled($tmp1,$src,0,0,0,0,$newwidth1,$newheight1,$width,$height);
                    imagecopyresampled($tmp2,$src,0,0,0,0,$newwidth2,$newheight2,$width,$height);
                    imagecopyresampled($tmp3,$src,0,0,0,0,$newwidth3,$newheight3,$width,$height);

                    $filename = "../shop_image/large/".$image5;
                    $filename1 = "../shop_image/md/".$image5;
                    $filename2 = "../shop_image/sm/".$image5;
                    $filename3 = "../shop_image/xs/".$image5;

                    imagejpeg($tmp,$filename,100);
                    imagejpeg($tmp1,$filename1,100);
                    imagejpeg($tmp2,$filename2,100);
                    imagejpeg($tmp3,$filename3,100);

                    imagedestroy($src);
               }
         }
}

if($_SERVER["REQUEST_METHOD"] == "POST"){
$g116=end(explode('.',$_FILES['image6']['name']));
$image6='item_'.md5(rand()).'.'.$g116;
$uploadedfile6 = $_FILES['image6']['tmp_name'];
   if ($image6){
             $filename = stripslashes($_FILES['image6']['name']);
             $extension = getExtension($filename);
           $extension = strtolower($extension);
           if (($extension != "jpg") && ($extension != "jpeg") && ($extension != "png") && ($extension != "gif")){
               $change='<div class="msgdiv">Unknown Image extension </div> ';
               $errors=1;
           }
           else{
                    $size=filesize($_FILES['image6']['tmp_name']);
                    if ($size > MAX_SIZE*1024){  
                      $change='<div class="msgdiv">You have exceeded the size limit!</div> ';
                      $errors=1;
                    }
                    if($extension=="jpg" || $extension=="jpeg" ){
                       $uploadedfile6 = $_FILES['image6']['tmp_name'];
                       $src = imagecreatefromjpeg($uploadedfile6);
                    }
                    else if($extension=="png"){
                            $uploadedfile6 = $_FILES['image6']['tmp_name'];
                            $src = imagecreatefrompng($uploadedfile6);
                    }
                    else {
                          $src = imagecreatefromgif($uploadedfile6);
                    }
                    echo $scr;
                    list($width,$height)=getimagesize($uploadedfile6);
                    $newwidth=600;
                    $newheight=($height/$width)*$newwidth;
                    $newwidth1=332;
                    $newheight1=284;
                    $newwidth2=150;
                    $newheight2=150;
                    $newwidth3=36;
                    $newheight3=36;
                    $tmp=imagecreatetruecolor($newwidth,$newheight);
                    $tmp1=imagecreatetruecolor($newwidth1,$newheight1);
                    $tmp2=imagecreatetruecolor($newwidth2,$newheight2);
                    $tmp3=imagecreatetruecolor($newwidth3,$newheight3);

                    imagecopyresampled($tmp,$src,0,0,0,0,$newwidth,$newheight,$width,$height);
                    imagecopyresampled($tmp1,$src,0,0,0,0,$newwidth1,$newheight1,$width,$height);
                    imagecopyresampled($tmp2,$src,0,0,0,0,$newwidth2,$newheight2,$width,$height);
                    imagecopyresampled($tmp3,$src,0,0,0,0,$newwidth3,$newheight3,$width,$height);

                    $filename = "../shop_image/large/".$image6;
                    $filename1 = "../shop_image/md/".$image6;
                    $filename2 = "../shop_image/sm/".$image6;
                    $filename3 = "../shop_image/xs/".$image6;

                    imagejpeg($tmp,$filename,100);
                    imagejpeg($tmp1,$filename1,100);
                    imagejpeg($tmp2,$filename2,100);
                    imagejpeg($tmp3,$filename3,100);

                    imagedestroy($src);
               }
         }
}

     $price=$_POST['price'];
     $mrp=$_POST['mrp'];
     $sub_cat=$_POST['sub_cat'];
     $sub_p=$_POST['sub_cat_p'];
     $category=$_POST['category'];
     $description=$_POST['content'];
     $weight=$_POST['weight'];
     $quantity=$_POST['quantity'];
     $danger=$_POST['danger'];
     $cprice=$_POST['cprice'];
     $status=$_POST['status'];
$c_s="SELECT * FROM product where title='$title' and mrp ='$mrp' and weight ='$weight' ";
$c_q=mysqli_query($con,$c_s);
$c_f=mysqli_num_rows($c_q);
if($c_f >= 1){
  echo "<script>alert('Product already exist.');</script>";
              echo "<script>window.open('gallery_add.php','_self')</script>";
              exit();

}
     $sql="INSERT INTO  product (title, image ,image1,image2,image3,image4,image5, price ,category ,weight,description,mrp,sub_cat,status,personal,quantity,danger,cprice) VALUES ('$title','$image1','$image2','$image3','$image4','$image5','$image6','$price','$category','$weight','$description','$mrp','$sub_cat','$status','$sub_p','$quantity','$danger','$cprice')" or die(mysqli_error());
     $run=mysqli_query($con,$sql) or die(mysqli_error());
     if($run){
              echo "<script>alert('New Record Inserted Successfully','_self');</script>";
              echo "<script>window.open('gallery_add.php','_self')</script>";

             }
     else{
          echo "<script>alert('Data not Inserted.');</script>";
         }
}
?>