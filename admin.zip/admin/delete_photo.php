<?php 
include('dbcon.php');
$id=$_GET['id'];

$query="SELECT * from product where id='$id' " or die(mysqli_error($con));
$sql=mysqli_query($con,$query);
$row=mysqli_fetch_array($sql);
$img2=$row[2];
$img3=$row[3];
$img4=$row[4];
$img5=$row[5];
$img6=$row[6];
$img7=$row[7];


unlink("../shop_image/large/".$img2);
unlink("../shop_image/md/".$img2);
unlink("../shop_image/sm/".$img2);
unlink("../shop_image/xs/".$img2);

unlink("../shop_image/large/".$img3);
unlink("../shop_image/md/".$img3);
unlink("../shop_image/sm/".$img3);
unlink("../shop_image/xs/".$img3);

unlink("../shop_image/large/".$img4);
unlink("../shop_image/md/".$img4);
unlink("../shop_image/sm/".$img4);
unlink("../shop_image/xs/".$img4);

unlink("../shop_image/large/".$img5);
unlink("../shop_image/md/".$img5);
unlink("../shop_image/sm/".$img5);
unlink("../shop_image/xs/".$img5);

unlink("../shop_image/large/".$img6);
unlink("../shop_image/md/".$img6);
unlink("../shop_image/sm/".$img6);
unlink("../shop_image/xs/".$img6);

unlink("../shop_image/large/".$img7);
unlink("../shop_image/md/".$img7);
unlink("../shop_image/sm/".$img7);
unlink("../shop_image/xs/".$img7);

mysqli_query($con,"DELETE  from product where id='$id'")or die(mysql_error());
header('location:gallery_add.php');
?>