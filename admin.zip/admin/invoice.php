<?php
include('session.php');
$idm=$_GET['inv'];
?>

<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="css/main.css" rel="stylesheet" type="text/css">

<style>
@media print { @page { margin: 0; } body { margin: 1.6cm; } }
</style>
<div class="navbar navbar-inverse">
     <div class="navbar-inner">
          <ul class="nav"> 
              <li class="divider-vertical"></li><li class="divider-vertical"></li><li class="divider-vertical"></li>
              <li class="divider-vertical"></li>
              <li><a href="admin.php">Admin</a></li> <li class="divider-vertical"></li>
              <li><a href="gallery_add.php">Grocery</a></li>  <li class="divider-vertical"></li>
              <li><a href="order.php">Orders</a></li>  <li class="divider-vertical"></li>
              <li><a href="Delivered.php">Delivered</a></li>  <li class="divider-vertical"></li>
              <li  ><a href="cancelled.php">Cancelled</a></li>  <li class="divider-vertical"></li>
              <li><a href="grocery_danger.php">Danger</a></li>  <li class="divider-vertical"></li>
              <li><a href="grocery_hidden.php">Hidden</a></li>  <li class="divider-vertical"></li>
              <li><a href="grocery_stock.php">Out of Stock</a></li>  <li class="divider-vertical"></li>
          </ul>
     </div>
</div>
<body>
     <div class="container" id="mydiv">
          <div class="row-fluid">
               <div class="span12">
                    <div class="span12">
                         <legend></legend>


<?php
                                    $query="SELECT * from customer_order_details where id='$idm' " or die(mysqli_error());
                                    $sql=mysqli_query($con,$query);
                                    while($row=mysqli_fetch_array($sql)){
                                    $c_id=$row[1];
                                    $p_id=$row[2];
                                    
                                ?>
        <!-- main -->                        
      <div class="content">
        <div class="main-content">
          <!-- INVOICE -->
          <div class="invoice">
            <!-- invoice header -->
            <div class="invoice-header">
              <div class="row">
                <div class="col-lg-3 col-print-3">
                  <img src="../img/Raftaa.png" alt="Raafta Logo" width="100"/>
                </div>
                <div class="col-lg-9 col-print-9">
                  <ul class="list-inline">
                    <li>Invoice #: <strong><?php echo $row[0]; ?></strong></li>
                    <li>Invoice Date: <strong><?php echo $row[7]; ?></strong></li>
                  </ul>
                </div>
              </div>
            </div>
            <!-- end invoice header -->
            <!-- invoice address -->
            <div class="invoice-from-to">
              <div class="row">
                <div class="col-sm-6 col-print-6">
                  <span>TO</span>
                  <p class="name"><?php echo $row[3]; ?></p>
                  <address>
                    <?php echo $row[4]; ?>
                    <br /> <?php echo $row[5]; ?>
                    <br />
                    <div class="contact">
                      <p><span>Phone:</span> <?php echo $row[6]; ?></p>
                    </div>
                  </address>
                </div>
                <div class="col-sm-6 col-print-6">
                  <span>FROM</span>
                  <p class="name">Raafta</p>
                  <address>
                    6th Floor, Bansal Arcade, P.P. Compound
                    <br /> Ranchi, 834001
                    <br />
                    <div class="contact">
                      <p><span>Email:</span> admin@raafta.com</p>
                      <p><span>Phone:</span> 9504170776</p>
                    </div>
                  </address>
                </div>
              </div>
            </div>
            <!-- end invoice address -->
            <!-- invoice item table -->
            <div class="table-responsive">
              <table class="table invoice-table">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Item Name</th>
                    <th>MRP</th>
                    <th>Quantity</th>
                    <th>Rate</th>
                    <th>Amount</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                      $i=0;
                      $total=0;
                      $mrp=0;
                      $query8="SELECT * from customer_orders where invoice='$c_id' and cust_id='$p_id' " or die(mysqli_error());
                      $sql8=mysqli_query($con,$query8);
                      while($row8=mysqli_fetch_array($sql8)){
                      $i+=1;
                      $total+=$row8[6];
                      $mrp_i=$row8['p_id'];
                      $mrp_s=$row8['mrp']*$row8[5];
                      $mrp+=$mrp_s;
                    ?>
                  <tr>
                    <td><?php echo $i; ?></td>
                    <td><?php echo $row8[4].' '.$row8[7]; ?></td>
                    <td><span class="fa fa-rupee"></span> <?php echo $row8['mrp']; ?></td>
                    <td><?php echo $row8[5]; ?></td>
                    <td><span class="fa fa-rupee"></span> <?php echo $row8['price']; ?></td>
                    <td style="text-align:left;"><span class="fa fa-rupee"></span> <?php echo $row8[6]; ?></td>
                  </tr>
                  <?php } ?>
                  <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td style="font-size:16px;">Total</td>
                    <td style="text-align:left;font-size:16px;"><span class="fa fa-rupee"></span> <?php echo $total; ?></td>
                  </tr>
                    <?php if($mrp-$total<=0){}else{ ?>
                  <tr>
                    <td colspan="6" style="text-align:center;font-size:16px;">
                    Your Savings on this Purchase : <span class="fa fa-rupee"></span> <?php echo $mrp-$total; ?>
                    </td>
                  </tr>
                  <?php } ?>
                </tbody>
              </table>
            </div>
            <!-- end invoice item table -->
            <!-- invoice footer -->
            <div class="invoice-footer">
              <div class="row">
                <div class="col-sm-5 col-sm-offset-1 col-print-4 col-print-offset-2 right-col">
                  <div class="invoice-total">
                    <div class="row">
                      <div class="col-xs-4 col-xs-offset-4 col-print-6 col-print-offset-2">
                        
                      </div>
                      <div class="col-xs-4 text-right col-print-4">
                        
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-sm-12 col-print-12 left-col" style="text-align:center;">
                    <strong>Thankyou for giving us this wonderful opportunity to serve you.</strong><br>
                    <strong>Truly it is our pleasure.</strong><br>
                    <strong>You are a valuable customer to us.</strong>
                </div>
                <div class="col-sm-6 col-print-6 left-col">
                  <blockquote class="invoice-notes">
                    <strong>Notes:</strong>
                    <p>Please check all items at the time of delivery.</p>
                  </blockquote>
                </div>
              </div>
            </div>
            <!-- end invoice footer -->
            <!-- invoice action buttons -->
            <div class="invoice-buttons">
              <button class="btn btn-custom-primary print-btn"><i class="icon icon-print icon-large"></i> Print</button>
            </div>
            <!-- end invoice action buttons -->
          </div>
          <!-- INVOICE -->
        </div>
      </div>
      <!-- /main -->

<?php } ?>


                    </div> 
                   
              </div>
         </div>
    </div>
  <script >

$('.print-btn').click( function(){
window.print();
  });
  </script>
</body>
<?php include('footer.php'); ?>

