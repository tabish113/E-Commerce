<?php 
include('session.php');
?>
<div class="navbar navbar-inverse">
     <div class="navbar-inner">
          <ul class="nav"> 
              <li class="divider-vertical"></li><li class="divider-vertical"></li><li class="divider-vertical"></li>
              <li class="divider-vertical"></li>
              <li><a href="admin.php">Admin</a></li> <li class="divider-vertical"></li>
              <li  class="active"><a href="#">Add Product</a></li>  <li class="divider-vertical"></li>
              <li><a href="order.php">Orders</a></li>  <li class="divider-vertical"></li>
              <li  ><a href="Delivered.php">Delivered</a></li>  <li class="divider-vertical"></li>
              <li  ><a href="cancelled.php">Cancelled</a></li>  <li class="divider-vertical"></li>
              <li><a href="grocery_danger.php">Danger</a></li>  <li class="divider-vertical"></li>
              
          </ul>
     </div>
</div>
<body>
     <div class="container"><br>
          <div class="row-fluid">
               <div class="span12">
                    <div class="span9">
                         <div class="alert alert-success">
                               <h4>Product List</h4>
                         </div>
                         <legend></legend>
                         <table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example">
                         <caption></caption>
                         <thead>
                               <tr>
                                  <th>Title</th>
                                  <th>Image</th>
                                  <th width="100">Price</th>
                                  <th>Description</th>
                                  <th width="180">Action</th>
                              </tr>
                        </thead>
                        <tbody>
                              <?php
                                    $query="SELECT * from product where status='stock'" or die(mysqli_error());
                                    $sql=mysqli_query($con,$query);
                                    while($row=mysqli_fetch_array($sql)){
                                    $id1=$row['id'];
                                    $title1=$row['nm'];
                                    $image1=$row['img1'];
                                    $mrp=$row['mrp'];
                                    $price=$row['price'];
                                    $cp=$row['cp'];
                                     
                                    $feature=$row['feature'];
                                    
                                    $des=substr($row['des'],0,100);
                                ?>
                               <tr>
                                  <td><b><?php echo $title1;?></b><br>
                                    
                                  </td>
                                  
                                  <td>
                                      MRP : <span class="fa fa-rupee"></span> <?php echo $mrp;?><br>
                                      SP : <span class="fa fa-rupee"></span> <?php echo $price;?><br>
                                      CP : <span class="fa fa-rupee"></span> <?php echo $cp;?>
                                  </td>

                                  <td><?php echo $des;?></td>
                                  <td><?php echo $feature;?></td>

                                  <td width="180">
                                      <a data-toggle="modal" href="#<?php echo 's'.$id1; ?>"  class="btn btn-warning" ><i class="icon-pencil icon-large"></i>&nbsp; Edit</a>
                                      <a data-toggle="modal" href="#<?php echo $id1; ?>" class='btn btn-danger'>  <i class="icon-trash icon-large"></i>&nbsp;Delete</a>                                     
                                  </td> 
                               </tr>
                               <?php
                                    include('modal_delete_photo.php');
                                    include('edit_photos.php');
                              }  ?>
                         </tbody>
                         </table>
                    </div> 
                    <?php include('session_sidebar.php'); ?>
                    <div class="well">
                         <a button class="btn btn-block btn-success" type="button" href="#addphotos" role="button"  data-toggle="modal"><i class="icon-pencil"></i> Add Product</button></a>
                   <?php include('modal_addphotos.php'); ?>
                   </div>
              </div>
         </div>
    </div>
</body>
<?php include('footer.php'); ?>