<!DOCTYPE html>
<html>
<head>
      <title>Raafta Admin</title>
      <link rel="shortcut icon" href="../img/favicon.png">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="stylesheet" type="text/css" href="css/DT_bootstrap.css">
      <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="screen">
      <link href="css/bootstrap-responsive.css" rel="stylesheet" type="text/css" media="screen">
      <link href="css/font-awesome.css" rel="stylesheet" type="text/css" media="screen">
      <script src="js/jquery.js" type="text/javascript"></script>
      <script src="js/bootstrap.js" type="text/javascript"></script>
      <script type="text/javascript" charset="utf-8" language="javascript" src="js/jquery.dataTables.js"></script>
      <script type="text/javascript" charset="utf-8" language="javascript" src="js/DT_bootstrap.js"></script>
      <link href="../css/fonts.css" rel="stylesheet" type="text/css">




            <!-- CSS -->
</head>      
