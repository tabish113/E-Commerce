<?php
include('session.php');
?>
<div class="navbar navbar-inverse" >
     <div class="navbar-inner" >
          <ul class="nav"> 
              <li class="divider-vertical"></li><li class="divider-vertical"></li><li class="divider-vertical"></li>
              <li class="divider-vertical"></li>
              <li  ><a href="admin.php">Admin</a></li> <li class="divider-vertical"></li>
             
              <li><a href="order.php">Order</a></li>  <li class="divider-vertical"></li>
              <li><a href="contact.php">Contact</a></li>  <li class="divider-vertical"></li>
              <li class="active"><a href="redeem.php">Redeem</a></li>  <li class="divider-vertical"></li>

          </ul>
     </div>
</div>
<body>
     <div class="container"><br>
          <div class="row-fluid">
                <div class="span12">
                     <div class="span9">
                           <div class="alert alert-success">
                                 <h4>Admin List</h4>
                           </div>
                           <legend></legend>
                           <table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example">
                           <caption></caption>
                                    <thead>
                                           <tr>
                                              <th>Name</th>
                                              <th>No.</th>
                                              <th>Bank Name</th>
                                              <th width="180">Account No.</th>
                                              <th width="180">IFSC</th>
                                              <th width="180">Amount</th>

                                           </tr>
                                     </thead>
                                     <tbody>
                                           <?php
                                                $query="SELECT * from redeem" or die(mysqli_error($con));
                                                $sql=mysqli_query($con,$query)or die(mysqli_error($con));
                                                while($row=mysqli_fetch_array($sql)){
                                                $userid=$row['userid'];
                                                $bnm=$row['nm'];
                                                $acno=$row['acno'];
                                                $ifsc=$row['ifsc'];
                                                $amount=$row['credit'];
                                                
                                                $query1="SELECT * from register where cno='$userid'" or die(mysqli_error($con));
                                                $sql1=mysqli_query($con,$query1)or die(mysqli_error($con));
                                                $row1=mysqli_fetch_array($sql1);
                                                $nm=$row1['nm'];
                                                $no=$row1['no'];
                                            ?>
                                            <tr>
                                              <td><?php echo $nm;?></td>
                                              <td><?php echo $no;?></td>
                                              <td><?php echo $bnm;?></td>
                                              <td><?php echo $acno;?></td>
                                              <td><?php echo $ifsc;?></td>
                                              <td><?php echo $amount;?></td>

                                              <td width="180">
                                                  <a data-toggle="modal" href="#<?php echo 'edit'.$id7; ?>"  class="btn btn-warning" ><i class="icon-pencil icon-large"></i>&nbsp; Edit</a>
                                                  <a data-toggle="modal" href="#<?php echo 'del'.$id7; ?>" class='btn btn-danger'>  <i class="icon-trash icon-large"></i>&nbsp;Delete</a>
                                              </td> 
                                          </tr>
                                          <?php
                                               include('modal_edit_admin.php');
                                               include('modal_delete_admin.php');
                                           } ?> 
                                      </tbody> 
                              </table>    
                         </div>
                         <?php include('session_sidebar.php'); ?>
                         <div class="well">
                              <a button class="btn btn-block btn-success" type="button" href="#addadmin" role="button"  data-toggle="modal"><i class="icon-edit icon-large"></i> Add Admin</button></a>
                         <?php include("modal_addadmin.php");?>
                         </div>
                   </div>
             </div>
       </div>
</body>
<?php   include('footer.php'); ?>