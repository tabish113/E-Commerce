<?php
session_start();
include('dbcon.php');
include('header.php'); 
?>
<div class="navbar navbar-inverse navber-fixed-top">
     <div class="navbar-inner">
          <a class="brand" href="#"></i></a> 
              <ul class="nav">
              </ul>
     </div>
</div>
<div class="container">
     <body>
          <div class="row-fluid">
               <div class="span12"><br>
                    <div class="span3">
                    </div>
                    <div class="span6"><br><br>
	                       <div class="well">
	                           <legend>
	                                   <div class="alert alert-success"><h4>Sign In</h4> </div>
                              </legend>
                              <form action="index.php" class="form-horizontal" method="POST">
                                    <div class="control-group">
                                          <label class="control-label" for="inputEmail">Username</label>
                                                 <div class="controls">
                                                     <input type="text" id="inputEmail" name="Username" placeholder="Username" class="span8" required>
                                                 </div>
                                      </div>
                                      <div class="control-group">
                                           <label class="control-label" for="inputPassword">Password</label>
                                                  <div class="controls">
                                                         <input type="password" id="inputPassword" name="Password" placeholder="Password" class="span8" required>
                                                    </div>
                                     </div>
                                     <div class="control-group">
                                            <div class="controls">
                                                 <button type="submit" name="login" class="btn btn-success"><i class="icon-signin"></i>&nbsp;Sign in</button>
                                            </div>
                                     </div>
                               </form>
                          </div>
                    </div>
              </div>
        </div>
   </body>
   <?php include('footer.php');  ?>
</div>
<?php 
if(isset($_POST['login'])){   
$name=($_POST['Username']);
$pass=($_POST['Password']);
$sql="SELECT * FROM login where user_name='$name' AND user_password='$pass'";
$run = mysqli_query($con,$sql) or die(mysqli_error($con));
if(mysqli_num_rows($run)>0){
    $_SESSION['Username']=$name;
    echo "<script>window.open('admin.php?logged=login successfully','_self')</script>";
}
else {
       echo "<script>alert('name and password not matched')</script>";
}
} 
?>