<?php
include("dbcon.php");
$idm=$_GET['inv'];
     $sql45="UPDATE  customer_order_details set status='Delivered' where id='$idm'  " or die(mysqli_error($con));
     $run45=mysqli_query($con,$sql45) or die(mysqli_error($con));
     if($run45){




$no="SELECT * FROM customer_order_details where id='$idm' ";
$qo=mysqli_query($con,$no);
$fo=mysqli_fetch_array($qo);
$sen=$fo['cust_id'];
$inv=$fo['invoice'];
  $n="SELECT * FROM register where cno='$sen'";
$q=mysqli_query($con,$n);
$f=mysqli_fetch_array($q);


$no1="SELECT * FROM customer_orders where invoice='$inv' and cust_id='$sen' ";
$qo1=mysqli_query($con,$no1);
while($fo1=mysqli_fetch_array($qo1)){
	$p_id=$fo1['p_id'];
	$quan=$fo1['quan'];

$no2="SELECT * FROM product where id='$p_id' ";
$qo2=mysqli_query($con,$no2);
$fo2=mysqli_fetch_array($qo2);


}

              echo "<script>alert('Order delivered successfully','_self');</script>";
              echo "<script>window.open('order.php','_self')</script>";

             }
?>