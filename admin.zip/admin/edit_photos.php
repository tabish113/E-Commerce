<div id="<?php echo 's'.$id1; ?>" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
     <div class="modal-header">
          <div class="alert alert-gray">
               Change/Modify Product
          </div>
          <div class="modal-body"><hr>
               <form class="form-horizontal" method="POST" enctype="multipart/form-data">
                     <div class="control-group">
                           <label class="control-label" for="inputEmail">Name</label>
                                  <div class="controls">
                                       <input name="id5" value="<?php echo $row[0]?>" type="hidden" id="inputEmail" placeholder="ID">
                                       <input type="text" value="<?php echo $row[1]; ?>" class="span10" id="inputEmail" name="title5" placeholder="Title" required class="span3">
                                  </div>
                     </div>
                     <div class="control-group">
                          <label class="control-label" for="input01">Image 1</label>
                                 <div class="controls">
                                      <input type="hidden" name="img1" value="<?php echo $row[2]; ?>" class="font">
                                      <input type="file" name="image1" class="font"> 
                                 </div>
                     </div>
                     
                     <div class="control-group">
                          <label class="control-label" for="inputEmail">MRP</label>
                                 <div class="controls">
                                      <input type="text" value="<?php echo $row[3]; ?>" class="span10" id="inputEmail" name="mrp" placeholder="MRP" required class="span3">
                                 </div>
                     </div>
                     <div class="control-group">
                          <label class="control-label" for="inputEmail">Cost Price</label>
                                 <div class="controls">
                                      <input type="text" value="<?php echo $row[5]; ?>" class="span10" id="inputEmail" name="cprice" placeholder="Cost Price" required class="span3">
                                 </div>
                     </div>
                     <div class="control-group">
                          <label class="control-label" for="inputEmail">Selling Price</label>
                                 <div class="controls">
                                      <input type="text" value="<?php echo $row[4]; ?>" class="span10" id="inputEmail" name="price5" placeholder="Selling Price" required class="span3">
                                 </div>
                     </div>

                     <div class="control-group">
                          <label class="control-label" for="inputEmail">Category</label>
                                 <div class="controls">
                                      <select name="category5"> 
                                                             <option value="<?php echo $row[8]; ?>"><?php echo $row[8]; ?></option>
                                             
                                                             <option value="HOUSEHOLD">HOUSEHOLD</option>
                                             
                                                             <option  value="tree">tree</option>
                                             </optgroup>
                                     </select>
                                </div>
                     </div>
                    

                     <div class="control-group">
                          <label class="control-label" for="inputEmail">Description</label>
                                 <div class="controls">
                                      <textarea rows="5" class="span10"  placeholder="Write your details here..!" name="content5"><?php echo $row[6]; ?></textarea>
                                 </div>
                    </div>
              
               

                <div class="control-group">
                          <label class="control-label" for="inputEmail">Feature</label>
                                 <div class="controls">
                                      <textarea rows="5" class="span10"   name="content5"><?php echo $row[7]; ?></textarea>
                                 </div>
                    </div>
               </div>



               <div class="modal-footer">
                     <button name="save1" type="submit" class="btn btn-success"><i class="icon-pencil"></i>&nbsp;Update</button>
                     <button class="btn" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i>&nbsp;Close</button>
              </form>  
      </div>
</div>
<?php
     if(isset($_POST['save1'])){
     $id6=$_POST['id5'];
     $title6=$_POST['title5'];

$imag1=$_POST['img1'];


error_reporting(0);
$change="";
$abc="";
define ("MAX_SIZE","400");
function getExtension($str) {
         $i = strrpos($str,".");
         if (!$i) { return ""; }
         $l = strlen($str) - $i;
         $ext = substr($str,$i+1,$l);
         return $ext;
}
$errors=0;

if($_FILES['image1']['name'] == ''){ 
$image1=$imag1;
}
else{
$image1=$imag1;
unlink("../product/".$image1);

if($_SERVER["REQUEST_METHOD"] == "POST"){
$g111=end(explode('.',$_FILES['image1']['name']));
$image1='item_'.md5(rand()).'.'.$g111;
$uploadedfile1 = $_FILES['image1']['tmp_name'];
   if ($image1){
             $filename = stripslashes($_FILES['image1']['name']);
             $extension = getExtension($filename);
           $extension = strtolower($extension);
           if (($extension != "jpg") && ($extension != "jpeg") && ($extension != "png") && ($extension != "gif")){
               $change='<div class="msgdiv">Unknown Image extension </div> ';
               $errors=1;
           }
           else{
                    $size=filesize($_FILES['image1']['tmp_name']);
                    if ($size > MAX_SIZE*1024){  
                      $change='<div class="msgdiv">You have exceeded the size limit!</div> ';
                      $errors=1;
                    }
                    if($extension=="jpg" || $extension=="jpeg" ){
                       $uploadedfile1 = $_FILES['image1']['tmp_name'];
                       $src = imagecreatefromjpeg($uploadedfile1);
                    }
                    else if($extension=="png"){
                            $uploadedfile1 = $_FILES['image1']['tmp_name'];
                            $src = imagecreatefrompng($uploadedfile1);
                    }
                    else {
                          $src = imagecreatefromgif($uploadedfile1);
                    }
                    echo $scr;
                    list($width,$height)=getimagesize($uploadedfile1);
                    $newwidth=600;
                    $newheight=($height/$width)*$newwidth;
                    $newwidth1=332;
                    $newheight1=284;
                    $newwidth2=150;
                    $newheight2=150;
                    $newwidth3=36;
                    $newheight3=36;
                    $tmp=imagecreatetruecolor($newwidth,$newheight);
                    $tmp1=imagecreatetruecolor($newwidth1,$newheight1);
                    $tmp2=imagecreatetruecolor($newwidth2,$newheight2);
                    $tmp3=imagecreatetruecolor($newwidth3,$newheight3);

                    imagecopyresampled($tmp,$src,0,0,0,0,$newwidth,$newheight,$width,$height);
                    imagecopyresampled($tmp1,$src,0,0,0,0,$newwidth1,$newheight1,$width,$height);
                    imagecopyresampled($tmp2,$src,0,0,0,0,$newwidth2,$newheight2,$width,$height);
                    imagecopyresampled($tmp3,$src,0,0,0,0,$newwidth3,$newheight3,$width,$height);

                    $filename = "../shop_image/large/".$image1;
                    $filename1 = "../shop_image/md/".$image1;
                    $filename2 = "../shop_image/sm/".$image1;
                    $filename3 = "../shop_image/xs/".$image1;

                    imagejpeg($tmp,$filename,100);
                    imagejpeg($tmp1,$filename1,100);
                    imagejpeg($tmp2,$filename2,100);
                    imagejpeg($tmp3,$filename3,100);

                    imagedestroy($src);
               }
         }
}     
}


     $price6=$_POST['price5'];
     $mrp=$_POST['mrp'];
     $sub_cat=$_POST['sub_cat'];
     $wht=$_POST['weight'];
     $status=$_POST['status'];
     $sub_p=$_POST['sub_cat_p'];
     
     $category6=$_POST['category5'];
     $description6=$_POST['content5'];
     $quantity=$_POST['quantity'];
     $danger=$_POST['danger'];
     $cprice=$_POST['cprice'];

     $sql45="UPDATE  product set title='$title6', image='$image1' ,image1='$image2' ,image2='$image3' ,image3='$image4',image4='$image5',image5='$image6', price='$price6',mrp='$mrp',sub_cat='$sub_cat',weight='$wht' ,category='$category6',status='$status' ,description='$description6',personal='$sub_p', quantity='$quantity', danger='$danger',cprice='$cprice' where id='$id6'" or die(mysqli_error());


     $run45=mysqli_query($con,$sql45) or die(mysqli_error());

    if($run45){
              $cart_s="UPDATE cart SET status='$status' WHERE product_id='$id6'";
              $run46=mysqli_query($con,$cart_s) or die(mysqli_error());

             }

     if($run46){
              echo "<script>alert('Product updated successfully');</script>";
              echo "<script>window.open('gallery_add.php','_self')</script>";

             }
}
?>